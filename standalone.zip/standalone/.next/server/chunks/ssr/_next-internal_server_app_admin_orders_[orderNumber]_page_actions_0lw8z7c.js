module.exports=[40918,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_orders_%5BorderNumber%5D_page_actions_0lw8z7c.js.map