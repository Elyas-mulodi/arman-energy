module.exports=[76043,a=>{"use strict";a.s(["default",0,function({children:a}){return a},"metadata",0,{title:"دسته‌بندی‌ها",description:"مشاهده‌ی تمام دسته‌بندی‌های موتور کولر و قطعات مرتبط در آرمان انرژی."}])},96474,function(a){a.n(a.i(76043))}];

//# sourceMappingURL=src_app_categories_layout_tsx_0om94mk._.js.map