module.exports=[31014,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_products_%5Bid%5D_edit_page_actions_1ar2s1q.js.map