module.exports=[89590,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_profile_orders_%5BordersNumber%5D_page_actions_0s5dja4.js.map