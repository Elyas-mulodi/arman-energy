module.exports=[5895,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_about_page_actions_0xvgj07.js.map