globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/gTISy3P1yExXJDV9nmFwy/_buildManifest.js",
    "static/gTISy3P1yExXJDV9nmFwy/_ssgManifest.js",
    "static/gTISy3P1yExXJDV9nmFwy/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/227kwhsrjlnp4.js",
    "static/chunks/2rwo-pv_owqp2.js",
    "static/chunks/turbopack-3u-qwj7j_gw0h.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
