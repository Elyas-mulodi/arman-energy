:HL["/_next/static/chunks/2ul62lrvteodu.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":4184,"slots":{"children":{"name":"categories","param":null,"prefetchHints":4196,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"gTISy3P1yExXJDV9nmFwy"}
