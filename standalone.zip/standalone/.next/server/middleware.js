var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1fyw3vo._.js")
R.c("server/chunks/[root-of-the-server]__1lrrla1._.js")
R.m(89997)
module.exports=R.m(89997).exports
